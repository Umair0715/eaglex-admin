import Sidebar from "components/global/sidebar";
import Dashboard from "pages/dashboard";
import Offers from "pages/offers";
import AddNewOffer from "pages/offers/AddNewOffer";
import EditOffer from "pages/offers/EditOffer";
import Users from "pages/user";
import EditUser from "pages/user/EditUser";
import { BrowserRouter as Router , Routes , Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";



function App() {
    return (
        <div className="space">
            <ToastContainer 
                style={{fontSize: 15}}
                position="top-center"
                autoClose={3000}
                closeOnClick
                pauseOnHover
            />
            <Router>
            <Sidebar />
                <Routes>
                    <Route path='/' element={<Dashboard />} />
                    <Route path='/user-management/users' element={<Users />} />
                    <Route path='/user-management/edit-user/:id' element={<EditUser />} />
                    <Route 
                    path='/offers-management/offers' 
                    element={<Offers />} 
                    />
                    <Route 
                    path='/offers-management/add-new' 
                    element={<AddNewOffer />} 
                    />
                    <Route 
                    path='/offers-management/edit-offer' 
                    element={<EditOffer />} 
                    />
                </Routes>
            </Router>
        </div> 
    );
}

export default App;
