import React from 'react'

const DashboardSvg = () => {
    return (
        <svg width="17" height="12" viewBox="0 0 17 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M8.5 11C11.25 11 16 6.25 16 6C16 5.75 11.25 1 8.5 1C5.75 1 1 5.875 1 6C1 6.125 5.75 11 8.5 11Z" stroke="#FDA955" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M8.5 7.25C9.88071 7.25 11 6.13071 11 4.75C11 3.36929 9.88071 2.25 8.5 2.25C7.11929 2.25 6 3.36929 6 4.75C6 6.13071 7.11929 7.25 8.5 7.25Z" stroke="#FDA955" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>

    )
}

export default DashboardSvg