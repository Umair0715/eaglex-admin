import Input from 'components/global/Input'
import React, { useState } from 'react'

const AddNewOfferForm = () => {
    const [name , setName] = useState('');

    return (
        <div className='mt-6 shadow-bg p-4'>
            <form className='flex flex-col gap-4'>
                <div className='flex items-center justify-between gap-4'>
                    <Input
                    label='Offer Name'
                    placeholder='Ex : Opal'
                    />
                    <Input
                    label='Company Name'
                    placeholder='Ex : Tesla'
                    />
                </div>
                <div className='flex items-center justify-between gap-4'>
                    <Input
                    type='number'
                    label='Profit Percentage %'
                    placeholder='Ex : 10 , 12 etc'
                    />
                    <Input
                    label='Time Period In Days'
                    placeholder='Ex : 15 , 30 , 40'
                    />
                </div>
                <div className='mt-4'>
                    <button className="btn-primary py-2 px-12">Save</button>
                </div>
            </form>
        </div>
    )
}

export default AddNewOfferForm