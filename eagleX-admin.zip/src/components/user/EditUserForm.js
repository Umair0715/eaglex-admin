import Input from 'components/global/Input'
import React, { useState } from 'react'

const EditUserForm = () => {
    const [name , setName] = useState('');

    return (
        <div className='mt-6 shadow-bg p-4'>
            <form className='flex flex-col gap-4'>
                <div className='flex items-center justify-between gap-4'>
                    <Input
                    label='First Name'
                    placeholder='Edit first name'
                    />
                    <Input
                    label='Last Name'
                    placeholder='Edit last name'
                    />
                </div>
                <div className='flex items-center justify-between gap-4'>
                    <Input
                    label='Phone Number'
                    placeholder='Edit phone number'
                    />
                    <Input
                    type='password'
                    label='Password'
                    placeholder='Edit password'
                    />
                </div>
                <div className='mt-4'>
                    <button className="btn-primary py-2 px-12">Save</button>
                </div>
            </form>
        </div>
    )
}

export default EditUserForm