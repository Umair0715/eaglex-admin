import axios from "axios";

// export const baseURL = 'https://ecom.immanuelkids.com';
export const baseURL = 'http://localhost:5000';



const Axios = axios.create({
    baseURL : `${baseURL}/api` ,
});

export default Axios;