export const products = [
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
    {
        id : 1 ,
        name : 'Black Watch',
        sold : '50' ,
        img : 'https://st2.depositphotos.com/1012015/5369/i/950/depositphotos_53695857-stock-photo-modern-watch-isolated-on-a.jpg'
    } ,
]