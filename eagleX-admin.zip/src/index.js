import React from 'react';
import ReactDOM from 'react-dom/client';
import './App.css';
import './utilities.css';
import App from './App';

import "react-datepicker/dist/react-datepicker.css";
import 'react-toastify/dist/ReactToastify.css';

import DrawerContextProvider from 'context/DrawerContext';
import store from 'redux/store';
import { Provider } from 'react-redux';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(

    <DrawerContextProvider>
        <Provider store={store}>
            <App />
        </Provider>
    </DrawerContextProvider>
);