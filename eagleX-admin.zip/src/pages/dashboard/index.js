import Cards from 'components/dashboard/Cards';
import RecentlyInvested from 'components/dashboard/RecentlyInvested';
import TopCustomers from 'components/dashboard/TopCustomers';
import Heading from 'components/global/Heading';
import Layout from 'components/global/Layout';
import UsersTable from 'components/user/UsersTable';
import { useState } from 'react'

const Dashboard = () => {
   
    return (
        <Layout>
            <div className='flex flex-col gap-8'>
                <h1 className='text-2xl font-semibold text-gray-500'>Welcome Back Admin</h1>
                <div>
                    <Cards />
                </div>
                <div>
                    <Heading title='Recently Invested' showIcon={false} />
                    <div className='mt-2'>
                        <RecentlyInvested />
                    </div>
                </div>
                <div>
                    <TopCustomers />
                </div>
            </div>
        </Layout>
    )
}

export default Dashboard