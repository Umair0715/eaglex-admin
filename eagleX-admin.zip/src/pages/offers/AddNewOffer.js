import BackBtn from 'components/global/BackBtn'
import Heading from 'components/global/Heading'
import Layout from 'components/global/Layout'
import AddNewOfferForm from 'components/offers/AddNewOfferForm'
import React from 'react'

const AddNewOffer = () => {
    return (
        <Layout>
            <div>
                <div className='flex items-center justify-between'>
                    <div>
                        <Heading title='Add New Offer' />
                    </div>
                    <div>
                        <BackBtn />            
                    </div>
                </div>
                <div>
                    <AddNewOfferForm />
                </div>
            </div>
        </Layout>
    )
}

export default AddNewOffer