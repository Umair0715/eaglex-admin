import BackBtn from 'components/global/BackBtn'
import Heading from 'components/global/Heading'
import Layout from 'components/global/Layout'
import Search from 'components/global/Search'
import OffersTable from 'components/offers/OffersTable'
import React from 'react'
import { Link } from 'react-router-dom'

const Offers = () => {
    return (
        <Layout>
            <div>
                <BackBtn />
                <div className='mt-4 flex items-center justify-between'>
                    <div>
                        <Heading title='All Offers' icon='clipboard-notes'  />
                    </div>
                    <div>
                        <Link
                        to='/offers-management/add-new' 
                        className="btn-primary py-2 px-6">
                            Add New
                        </Link>
                    </div>
                </div>
                <div className='mt-6'>
                    <OffersTable />
                </div>
            </div>
        </Layout>
    )
}

export default Offers