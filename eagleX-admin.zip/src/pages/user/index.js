import BackBtn from 'components/global/BackBtn'
import Heading from 'components/global/Heading'
import Layout from 'components/global/Layout'
import Search from 'components/global/Search'
import UsersTable from 'components/user/UsersTable'
import React from 'react'

const Users = () => {
    return (
        <Layout>
            <div>
                <BackBtn />
                <div className='mt-4 flex items-center justify-between'>
                    <div>
                        <Heading title='All Users' icon='clipboard-notes'  />
                    </div>
                    <div>
                        <Search />
                    </div>
                </div>
                <div className='mt-6'>
                    <UsersTable />
                </div>
            </div>
        </Layout>
    )
}

export default Users