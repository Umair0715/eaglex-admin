import Axios from "config/api";
import { addSubCategory, removeSubCategory, setSubCategories, setCreateLoading, setDeleteLoading , updateSubCategory , setLoading, setUpdateLoading, setPages, setCurrentPage } from "redux/reducers/subCategoryReducer";

const endPoint = `/sub-categories`

export const createSubCategory = (data , toast) => async (dispatch , getState) => {
    try {
        dispatch(setCreateLoading(true));
        const { token } = getState().auth.user;
        const { data : { data : { doc } } } = await Axios.post(endPoint , data , {
            headers : {
                Authorization : `Bearer ${token}`
            }
        });
        dispatch(addSubCategory(doc));
        dispatch(setCreateLoading(false));
        toast.success('Created successfully.');
    } catch (err) {
        dispatch(setCreateLoading(false));
        console.log('Create Sub category error:' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}


export const updateSubCat = (id , data , toast) => async (dispatch , getState) => {
    try {
        dispatch(setUpdateLoading(true));
        const { token } = getState().auth.user;
        const { data : { data : { doc } } } = await Axios.put(`${endPoint}/${id}` , data  , 
        { headers : { Authorization : `Bearer ${token}`} });
        dispatch(updateSubCategory(doc));
        dispatch(setUpdateLoading(false));
        toast.success('Updated Successfully.');
    } catch (err) {
        dispatch(setUpdateLoading(false));
        console.log('Update Sub Category error' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}


export const getSubCategories = (toast) => async (dispatch , getState) => {
    try {
        dispatch(setLoading(true));
        const { token } = getState().auth.user;
        const { data : { data : { docs , pages , page } } } = await Axios(`${endPoint}?page=${getState().subCategory.currentPage}` , {
            headers : {
                Authorization : `Bearer ${token}`
            }
        });
        dispatch(setSubCategories(docs));
        dispatch(setPages(pages));
        dispatch(setCurrentPage(page));
        dispatch(setLoading(false));
    } catch (err) {
        dispatch(setLoading(false));
        console.log('Get Sub categories error:' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}


export const deleteSubCategory = (id , toast) => async (dispatch , getState) => {
    try {
        dispatch(setDeleteLoading(true));
        const { token } = getState().auth.user;
        await Axios.delete(`${endPoint}/${id}` , 
            { headers : { Authorization : `Bearer ${token}`} }
        );
        dispatch(removeSubCategory(id));
        dispatch(setDeleteLoading(false));
        toast.success('Deleted Successfully.');
    } catch (err) {
        dispatch(setDeleteLoading(false));
        console.log('Delete Category error' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}


export const getTotalSubCategories = (toast) => async (dispatch) => {
    try {
        dispatch(setLoading(true));
        const { data : { data : { docs } } } = await Axios(`${endPoint}/all`);
        dispatch(setSubCategories(docs));
        dispatch(setLoading(false));
    } catch (err) {
        dispatch(setLoading(false));
        console.log('Get Total Sub categories error:' , err);
        toast.error(err?.response?.data?.message || err?.message || 'Something went wrong.');
    }
}